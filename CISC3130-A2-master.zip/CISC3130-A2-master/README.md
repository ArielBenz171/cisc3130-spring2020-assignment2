# CISC3130-A2
Section: MY9 EMPLID: 23685698 Name: David Schykerynec

This repository is for Data Structures assignment 2

I am turning this in super late and honestly I'm just hoping for minor partial credit. 
